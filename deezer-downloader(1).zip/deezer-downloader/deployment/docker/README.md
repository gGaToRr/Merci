The Dockerfile uses `COPY . /app`. So the Dockerfile needs to be placed in the root directory of the project.
