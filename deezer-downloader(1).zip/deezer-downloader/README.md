# 🎵 Deezer Downloader Pro v3.0

Interface moderne et sécurisée pour télécharger de la musique depuis Deezer avec authentification, base de données et panel admin.

## ✨ Nouvelles Fonctionnalités v3.0

✅ **Authentification & Sécurité**
- Système de login/signup sécurisé avec JWT
- Hash des mots de passe avec Werkzeug
- Validation d'email et force du mot de passe
- Suivi des tentatives de connexion

✅ **Base de Données**
- SQLAlchemy ORM
- SQLite par défaut (PostgreSQL optionnel)
- Modèles: User, DownloadLog, LoginAttempt
- Migrations automatiques

✅ **Interface Moderne 2026**
- Design épuré avec animations fluides
- Gradients et glassmorphism
- Responsive mobile/tablet
- Dark mode professionnel
- Animations JavaScript avancées

✅ **Panel Admin**
<VOTRE_ARL>"- Dashboard avec statistiques
- Gestion des utilisateurs
- Suivi des connexions échouées
- Promotion/rétrogradation admin

✅ **Déploiement Facile**
- Docker Compose avec un seul commande
- Support PostgreSQL + Nginx
- Healthchecks automatiques
- Configuration par .env

---

## 🚀 Démarrage Rapide

### 1. Clone et configuration

```bash
git clone https://github.com/kmille/deezer-downloader.git
cd deezer-downloader

# Copier le fichier de configuration
cp .env.example .env

# Éditez .env et mettez votre ARL Deezer
nano .env
```

### 2. Obtenir votre token ARL

[Lire le guide d'extraction ARL](https://github.com/RemixDevTools/SpotifyPlaylistArchive/wiki/Deezer-ARL)

*(Besoin d'un compte Deezer gratuit. Prend 2 minutes)*

### 3. Lancer avec Docker Compose

```bash
# Démarrage simple
docker-compose up -d

# Ou avec PostgreSQL pour la production
docker-compose --profile production up -d
```

### 4. Accéder

- **App**: http://localhost:5000
- **Admin**: http://localhost:5000/admin

---

## 📋 Le Premier Démarrage

1. Allez sur http://localhost:5000
2. Cliquez sur **"Inscription"**
3. Créez votre compte
4. **Le premier compte créé est automatiquement admin** ⚡
5. Commencez à télécharger!

*Note: Pour changer le comportement, modifier `auth.py` ligne 30*

---

## 🎯 Utilisation

### Interface Principale

**Onglets disponibles:**
- 🔍 **Recherche**: Chercher et télécharger des chansons/albums/artistes
- 📋 **Liste**: Coller plusieurs titres ou uploader un fichier .txt
- 📊 **Queue**: État des téléchargements en cours
- 📁 **Fichiers**: Accéder aux musicques téléchargées

### Télécharger depuis une Liste

```
Artist - Title
Another Artist - Another Title
...
```

Formats acceptés:
- `Artist - Title`
- `Title` (cherche approximativement)
- `Artist feat. Other - Title`

### API REST

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "user",
    "password": "pass"
  }'

# Utiliser le token
TOKEN="eyJ0eXAiOiJKV1QiLCJhbGc..."

# Recherche
curl -X POST http://localhost:5000/api/search \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "The Weeknd - Blinding Lights",
    "type": "track"
  }'

# Télécharger depuis liste
curl -X POST http://localhost:5000/api/playlist/from-list \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "titles": ["The Weeknd - Blinding Lights", "Dua Lipa - Levitating"],
    "playlist_name": "Ma Playlist"
  }'
```

---

## 🛠️ Configuration

### Variables d'environnement

```bash
# Requis
DEEZER_COOKIE_ARL=your_arl_here

# Optionnel
PORT=5000
JWT_SECRET_KEY=your-secret-key
FLASK_ENV=production
DATABASE_URL=sqlite:///deezer_downloader.db

# Pour PostgreSQL
DATABASE_URL=postgresql://user:password@postgres:5432/deezer
```

### Base de Données

**SQLite** (défaut):
```bash
# Déjà inclus, aucune config nécessaire
```

**PostgreSQL** (production):
```bash
docker-compose --profile production up -d
# Configure DATABASE_URL dans .env
```

---

## 👨‍💼 Panel Admin

**URL**: http://localhost:5000/admin

**Fonctionnalités:**
- 📊 Statistiques globales (utilisateurs, connexions)
- 👥 Liste des utilisateurs avec gestion
- 🔐 Suivi des connexions (dernières 24h)
- ❌ Tentatives échouées groupées par utilisateur
- ⚙️ Promotion/rétrogradation d'admin

**Accès:**
- Le premier utilisateur créé est automatiquement admin
- Les admins peuvent promouvoir d'autres utilisateurs

---

## 🔐 Sécurité

✅ **Implementé:**
- Hash de mots de passe avec Werkzeug
- JWT tokens avec expiration personnalisable
- Validation d'email
- Force du mot de passe (8+ chars, majuscule, chiffre)
- Suivi des tentatives de connexion
- Protection CSRF (à venir)
- Rate limiting (à venir)

⚠️ **À faire en production:**
- Changer `JWT_SECRET_KEY` dans `.env`
- Utiliser HTTPS minimum
- Configurer les CORS si nécessaire
- Ajouter un WAF (Web Application Firewall)
- Configurer les backups PostgreSQL

---

## 📂 Structure des Fichiers

```
deezer-downloader/
├── deezer_downloader/
│   ├── web/
│   │   ├── app.py                    # APP Flask principale
│   │   ├── auth.py                   # Routes authentification
│   │   ├── admin.py                  # Routes administration
│   │   ├── models.py                 # Modèles SQLAlchemy
│   │   ├── music_backend.py          # Logique téléchargement
│   │   ├── templates/
│   │   │   ├── index.html            # Interface principale
│   │   │   └── admin.html            # Panel admin
│   │   └── static/
│   │       ├── css/modern.css        # Styles 2026
│   │       └── js/
│   │           ├── app.js            # Logique app
│   │           └── animations.js     # Animations
│   ├── deezer.py                     # Deezer API
│   └── ...
├── docker-compose.yml                # Multi-services
├── Dockerfile
├── entrypoint.sh                     # Script démarrage
├── .env.example                      # Configuration
└── README.md
```

---

## 🐳 Docker

### Développement

```bash
docker-compose up -d

# Logs
docker-compose logs -f deezer-downloader
```

### Production

```bash
# Avec PostgreSQL + Nginx
docker-compose --profile production up -d
```

### Stop & Cleanup

```bash
docker-compose down
docker-compose down -v  # Inclure les volumes
```

---

## 🚦 Dépannage

### Le conteneur s'arrête

**Cause**: ARL invalide ou manquant

**Solution**:
```bash
grep DEEZER_COOKIE_ARL .env
docker-compose logs deezer-downloader
```

### Erreur 401 Unauthorized

**Cause**: Token JWT expiré ou invalide

**Solution**: Créez une nouvelle session via l'interface

### Base de données bloquée

**Cause**: SQLite avec accès concurrent

**Solution**: Utilisez PostgreSQL pour la production

### Port 5000 en utilisation

```bash
# Modifier dans .env
PORT=8080
docker-compose up -d
# Ensuite: http://localhost:8080
```

---

## 📊 API Endpoints

### Authentification

```
POST   /api/auth/signup              Créer un compte
POST   /api/auth/login               Connexion
GET    /api/auth/me                  Mes infos (JWT required)
POST   /api/auth/logout              Déconnexion
POST   /api/auth/change-password     Changer mot de passe
```

### Musique

```
POST   /api/search                   Rechercher
POST   /api/download/track/{id}      Télécharger chanson
POST   /api/download/album/{id}      Télécharger album
POST   /api/download/playlist/{id}   Télécharger playlist
POST   /api/playlist/from-list       Depuis liste
POST   /api/playlist/from-file       Depuis fichier
GET    /api/queue                    État queue
```

### Admin

```
GET    /api/admin/users              Liste utilisateurs
GET    /api/admin/users/{id}         Détail utilisateur
PUT    /api/admin/users/{id}/toggle-admin   Toggle admin
GET    /api/admin/login-attempts     Connexions (24h)
GET    /api/admin/login-attempts/failed     Échecs
GET    /api/admin/stats              Statistiques
```

---

## 🎬 Cas d'Usage

### Sauvegarder une Playlist Spotify

1. Exporter depuis Spotify
2. Coliez ou uploadez dans "Liste"
3. Cliquez "Télécharger"
4. ✅ Fait!

### Serveur Personnel

1. Lancez avec `docker-compose --profile production up -d`
2. Configurez Nginx avec votre domaine
3. Activez HTTPS avec Let's Encrypt
4. Accédez depuis n'importe où!

### Partager (multi-utilisateurs)

1. Créez des comptes pour vos amis
2. Le panel admin suit qui a téléchargé quoi
3. Gérez les permissions via les rôles

---

## 🔄 Développement

```bash
# Clone
git clone https://github.com/kmille/deezer-downloader.git
cd deezer-downloader

# Setup
python -m venv venv
source venv/bin/activate
pip install -e .

# Lancer
FLASK_ENV=development python -m deezer_downloader.cli.runner
```

---

## 📝 License

MIT

---

## 💪 Contribution

Les contributions sont bienvenues! Créez un issue ou PR directement.

---

**Besoin d'aide?**
- [Issues GitHub](https://github.com/kmille/deezer-downloader/issues)
- [Discussions](https://github.com/kmille/deezer-downloader/discussions)

**Faites un star ⭐ si vous aimez le projet!**
