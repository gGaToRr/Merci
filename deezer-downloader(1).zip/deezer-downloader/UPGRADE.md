# 📦 Guide de Migration v2 → v3

Cette nouvelle version est une refonte complète. Voici les changements majeurs.

## Ce qui change

### ✅ MAINTENU (compatible)

- ✅ Téléchargement depuis Deezer (chansons/albums/playlists)
- ✅ Support Spotify (parsing + download Deezer)
- ✅ Qualité audio personnalisable
- ✅ ZIP avec m3u8
- ✅ Intégration MPD
- ✅ Supports YouTube-DL

### 🔄 REFACTORISÉ (nouveau)

| v2 | v3 |
|----|---|
| Interface Bootstrap simple | Design moderne 2026 |
| Pas d'authentification | JWT + Login/Signup |
| Pas de base de données | SQLAlchemy + Modèles |
| API basique | API REST complète |
| Pas de panel admin | Admin dashboard complet |
| Config fichier CLI | Env vars + docker-compose |

### ❌ SUPPRIMÉ

- Config fichier INI (remplacé par .env)
- Admin par ligne de commande  
- Pas de traçabilité utilisateur

## Migration

### Option 1: Déploiement Frais (recommandé)

```bash
# Supprimer l'ancienne version
docker-compose down -v

# Clone nouvelle version
git clone https://github.com/kmille/deezer-downloader.git new-version
cd new-version

# Configurer
cp .env.example .env
nano .env  # Mettez votre ARL

# Lancer
docker-compose up -d
```

### Option 2: Migration depuis Installation Locale

```bash
# Backup
cp -r downloads/ downloads_backup/

# Update  
git pull
pip install --upgrade -e .

# New config
cp .env.example .env
nano .env

# Démarrer
export DEEZER_COOKIE_ARL="your_arl"
python -m deezer_downloader.web.app
```

## Données Existantes

**Fichiers téléchargés:** ✅ Toujours accessible
- Les fichiers restent dans `downloads/`
- Même structure de répertoire
- Migration automatique

**Fichiers config:** ⚠️ À refaire
- Ancien `deezer-downloader.ini` → `.env`
- Env vars remplacent les paramètres INI

**Base de données:** 📦 Nouvelle
- Les anciens logs ne sont pas importés
- Les nouveaux logs vont dans la base

## Configuration

### Ancienne méthode

```ini
[deezer]
cookie_arl = your_arl
quality = 320
```

### Nouvelle méthode

```bash
# .env
DEEZER_COOKIE_ARL=your_arl
FLASK_ENV=production
JWT_SECRET_KEY=super-secret-key
```

## Dashboard Admin

**Nouveau!** Allez sur `/admin` pour:
- 📊 Voir les statistiques globales
- 👥 Gérer les utilisateurs
- 🔐 Suivi des connexions
- ⚠️ Tentatives échouées

## API

**L'ancienne API est remplacée!**

Au lieu de tout publier sans auth:

```bash
# v2 - Pas de sécurité
POST /download/track/123

# v3 - Authentification JWT requise
POST /api/search
  Header: Authorization: Bearer TOKEN
  Body: {"query": "...", "type": "track"}
```

[Voir la doc API complète dans le README](README.md)

## Dépannage Migration

### Erreur: "No module named 'deezer_downloader.web.models'"

**Solution**: Réinstallez les dépendances

```bash
pip install --upgrade -r requirements.txt
# ou
poetry install
```

### Erreur: "Database is locked"

**Solution**: Supprimez la base et relancez

```bash
rm deezer_downloader.db
docker-compose up -d
```

### Ancien navigateur: "Network error"

**Solution**: Vider le cache

```bash
# Chrome/Firefox/Safari: Ctrl+Shift+Delete
# Puis rafraîchissez
```

### Panel Admin non accessible

**Solution**: Le premier compte créer être admin

```bash
# Créez un compte
# Connectez-vous
# Allez sur /admin
```

## Date de Fin de Support v2

- ⚠️ v2.x : Support limité
- ❌ v1.x : Plus de support

**Recommandation**: Migrez vers v3 pour:
- Sécurité améliorée
- Interface moderne
- Support multi-utilisateurs
- Mises à jour régulières

## Questions?

- Ouvrez une [issue GitHub](https://github.com/kmille/deezer-downloader/issues)
- Consultez les [discussions](https://github.com/kmille/deezer-downloader/discussions)

---

Bienvenue dans Deezer Downloader Pro v3! 🎵🚀
