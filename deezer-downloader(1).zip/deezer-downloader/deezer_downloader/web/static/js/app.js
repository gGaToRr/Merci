/**
 * Application principale - Deezer Downloader Pro
 */

const API_ROOT = '{{ api_root }}';
let authToken = localStorage.getItem('auth_token');
let currentUser = null;

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
});

function initializeApp() {
    if (authToken) {
        validateToken();
    } else {
        showAuthModal();
    }
}

// Validation du token
function validateToken() {
    $.ajax({
        url: `${API_ROOT}/api/auth/me`,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`
        },
        success: function(data) {
            currentUser = data;
            showApp();
            loadQueueStatus();
            setInterval(loadQueueStatus, 3000);
        },
        error: function() {
            localStorage.removeItem('auth_token');
            showAuthModal();
        }
    });
}

// Authentification - Login
function setupEventListeners() {
    // Auth modal tabs
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchAuthTab(this.dataset.tab);
        });
    });

    // Forms
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('signupForm').addEventListener('submit', handleSignup);

    // File upload drag & drop
    const fileUpload = document.querySelector('.file-upload');
    if (fileUpload) {
        fileUpload.addEventListener('dragover', (e) => {
            e.preventDefault();
            fileUpload.style.borderColor = 'var(--primary)';
            fileUpload.style.background = 'rgba(99, 102, 241, 0.1)';
        });

        fileUpload.addEventListener('dragleave', () => {
            fileUpload.style.borderColor = 'rgba(99, 102, 241, 0.3)';
            fileUpload.style.background = 'transparent';
        });

        fileUpload.addEventListener('drop', (e) => {
            e.preventDefault();
            const files = e.dataTransfer.files;
            if (files.length) {
                document.getElementById('titlesFile').files = files;
            }
        });
    }
}

function switchAuthTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    
    document.querySelector(`.auth-tab[data-tab="${tab}"]`).classList.add('active');
    document.getElementById(`${tab}Form`).classList.add('active');
    
    // Clear errors
    document.getElementById(`${tab}Error`).classList.remove('show');
}

function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');

    $.ajax({
        url: `${API_ROOT}/api/auth/login`,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            username: username,
            password: password
        }),
        success: function(data) {
            authToken = data.access_token;
            currentUser = data.user;
            localStorage.setItem('auth_token', authToken);
            showApp();
            showToast('Connexion réussie!', 'success');
        },
        error: function(xhr) {
            const error = xhr.responseJSON?.error || 'Erreur de connexion';
            errorEl.textContent = error;
            errorEl.classList.add('show');
        }
    });
}

function handleSignup(e) {
    e.preventDefault();
    
    const username = document.getElementById('signupUsername').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const errorEl = document.getElementById('signupError');

    $.ajax({
        url: `${API_ROOT}/api/auth/signup`,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            username: username,
            email: email,
            password: password
        }),
        success: function(data) {
            showToast('Compte créé! Connectez-vous.', 'success');
            switchAuthTab('login');
            document.getElementById('loginForm').reset();
        },
        error: function(xhr) {
            const error = xhr.responseJSON?.error || 'Erreur d\'inscription';
            errorEl.textContent = error;
            errorEl.classList.add('show');
        }
    });
}

// UI
function showAuthModal() {
    document.getElementById('authModal').classList.remove('hidden');
    document.getElementById('appContainer').classList.add('hidden');
}

function showApp() {
    document.getElementById('authModal').classList.add('hidden');
    document.getElementById('appContainer').classList.remove('hidden');
    document.getElementById('currentUser').textContent = currentUser.username;
}

function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(`${tabName}Tab`).classList.add('active');
    event.target.closest('.nav-btn').classList.add('active');
}

function switchListMode(mode) {
    document.querySelectorAll('.list-mode').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.form-tab').forEach(el => el.classList.remove('active'));
    
    document.getElementById(`${mode}Mode`).classList.add('active');
    event.target.classList.add('active');
}

// Recherche
function search() {
    const query = document.getElementById('searchQuery').value.trim();
    const type = document.getElementById('searchType').value;
    const resultsEl = document.getElementById('searchResults');

    if (!query) {
        showToast('Entrez une requête de recherche', 'warning');
        return;
    }

    resultsEl.innerHTML = '<p style="color: white; text-align: center; padding: 40px;">Recherche en cours...</p>';

    $.ajax({
        url: `${API_ROOT}/api/search`,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify({
            query: query,
            type: type
        }),
        success: function(data) {
            displaySearchResults(data.results, type);
        },
        error: function() {
            resultsEl.innerHTML = '<p style="color: var(--danger); text-align: center; padding: 40px;">Erreur de recherche</p>';
        }
    });
}

function displaySearchResults(results, type) {
    const resultsEl = document.getElementById('searchResults');
    resultsEl.innerHTML = '';

    if (!results || results.length === 0) {
        resultsEl.innerHTML = '<p style="color: rgba(255, 255, 255, 0.6); text-align: center; padding: 40px;">Aucun résultat trouvé</p>';
        return;
    }

    results.forEach(item => {
        const card = createResultCard(item, type);
        resultsEl.appendChild(card);
    });
}

function createResultCard(item, type) {
    const div = document.createElement('div');
    div.className = 'search-result-item';
    
    const title = item.title || item.name || 'Sans titre';
    const artist = item.artist || '';
    
    div.innerHTML = `
        <h3>${title}</h3>
        <p>${artist}</p>
        <button class="btn btn-primary" onclick="downloadItem(${item.id}, '${type}')">
            <i class="fas fa-download"></i> Télécharger
        </button>
    `;
    
    return div;
}

function downloadItem(id, type) {
    $.ajax({
        url: `${API_ROOT}/api/download/${type}/${id}`,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify({
            add_to_playlist: false
        }),
        success: function(data) {
            showToast('Téléchargement lancé!', 'success');
            showTab('queue');
        },
        error: function(xhr) {
            showToast(xhr.responseJSON?.error || 'Erreur', 'error');
        }
    });
}

// Télécharger depuis liste
function downloadList() {
    const playlistName = document.getElementById('playlistName').value.trim();
    
    if (!playlistName) {
        showToast('Entrez le nom de la playlist', 'warning');
        return;
    }

    let titles = [];
    const mode = document.querySelector('.list-mode.active').id;

    if (mode === 'textareaMode') {
        titles = document.getElementById('titlesList').value
            .split('\n')
            .map(t => t.trim())
            .filter(t => t.length > 0);
    } else {
        const file = document.getElementById('titlesFile').files[0];
        if (!file) {
            showToast('Sélectionnez un fichier', 'warning');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            titles = e.target.result
                .split('\n')
                .map(t => t.trim())
                .filter(t => t.length > 0);
            
            sendDownloadRequest(titles, playlistName);
        };
        reader.readAsText(file);
        return;
    }

    if (titles.length === 0) {
        showToast('Entrez au moins un titre', 'warning');
        return;
    }

    sendDownloadRequest(titles, playlistName);
}

function sendDownloadRequest(titles, playlistName) {
    $.ajax({
        url: `${API_ROOT}/api/playlist/from-list`,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify({
            titles: titles,
            playlist_name: playlistName,
            add_to_playlist: document.getElementById('addToPlaylist').checked,
            create_zip: document.getElementById('createZip').checked
        }),
        success: function(data) {
            showToast(`${titles.length} titres en cours de téléchargement!`, 'success');
            document.getElementById('titlesList').value = '';
            document.getElementById('playlistName').value = '';
            document.getElementById('titlesFile').value = '';
            showTab('queue');
        },
        error: function(xhr) {
            showToast(xhr.responseJSON?.error || 'Erreur', 'error');
        }
    });
}

// Queue
function loadQueueStatus() {
    $.ajax({
        url: `${API_ROOT}/api/queue`,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`
        },
        success: function(data) {
            displayQueue(data);
        }
    });
}

function displayQueue(queueData) {
    const queueEl = document.getElementById('queueList');
    
    if (!queueData.queue || queueData.queue.length === 0) {
        queueEl.innerHTML = '<p style="color: rgba(255, 255, 255, 0.6); text-align: center; padding: 40px;">Aucun téléchargement en cours</p>';
        return;
    }

    queueEl.innerHTML = queueData.queue.map(item => `
        <div class="queue-item">
            <div class="queue-item-title">${item.name || 'Téléchargement'}</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${item.progress || 0}%"></div>
            </div>
            <div class="queue-item-status">
                <span>${item.status || 'En cours'}</span>
                <span>${item.progress || 0}%</span>
            </div>
        </div>
    `).join('');
}

// Logout
function logout() {
    localStorage.removeItem('auth_token');
    authToken = null;
    currentUser = null;
    showAuthModal();
    document.getElementById('loginForm').reset();
    document.getElementById('signupForm').reset();
}

// Toast notifications
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease-in-out';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Utilitaires
window.showTab = showTab;
window.switchListMode = switchListMode;
window.search = search;
window.downloadItem = downloadItem;
window.downloadList = downloadList;
window.logout = logout;
