/**
 * Gestion du téléchargement depuis liste de titres
 * From List Download Feature
 */

$(document).ready(function() {

function hideFromListMessages() {
    $('#from-list-result').hide();
    $('#from-list-error').hide();
}

function showFromListSuccess(message) {
    hideFromListMessages();
    $('#from-list-result-text').text(message);
    $('#from-list-result').show();
}

function showFromListError(message) {
    hideFromListMessages();
    $('#from-list-error-text').text(message);
    $('#from-list-error').show();
}

/**
 * Télécharge depuis une liste (textarea)
 */
$('#from-list-download-textarea').click(function() {
    const titles = $('#from-list-textarea').val().trim().split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0);
    
    const playlistName = $('#from-list-playlist-name').val().trim();
    
    if (titles.length === 0) {
        showFromListError("Veuillez entrer au moins un titre");
        return;
    }
    
    if (!playlistName) {
        showFromListError("Veuillez entrer le nom de la playlist");
        return;
    }
    
    const data = {
        titles: titles,
        playlist_name: playlistName,
        add_to_playlist: $('#from-list-add-to-mpd').is(':checked'),
        create_zip: $('#from-list-create-zip').is(':checked')
    };
    
    $.ajax({
        type: 'POST',
        url: window.deezer_downloader_api_root + '/playlist/from-list',
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: function(response) {
            $.jGrowl(`✅ Téléchargement lancé! Task ID: ${response.task_id}`, {sticky: false, life: 5000});
            showFromListSuccess(`${titles.length} titre(s) en cours de téléchargement. Vérifiez l'onglet Queue pour le statut.`);
            // Vider les champs
            $('#from-list-textarea').val('');
            $('#from-list-playlist-name').val('');
        },
        error: function(xhr) {
            try {
                const response = JSON.parse(xhr.responseText);
                showFromListError("Erreur: " + response.error);
            } catch(e) {
                showFromListError("Erreur serveur: " + xhr.status);
            }
            $.jGrowl('❌ Erreur lors du téléchargement', {sticky: false, life: 5000});
        }
    });
});

/**
 * Télécharge depuis un fichier (file input)
 */
$('#from-list-download-file').click(function() {
    const fileInput = $('#from-list-file')[0];
    const playlistName = $('#from-list-playlist-name').val().trim();
    
    if (!fileInput.files || fileInput.files.length === 0) {
        showFromListError("Veuillez sélectionner un fichier");
        return;
    }
    
    if (!playlistName) {
        showFromListError("Veuillez entrer le nom de la playlist");
        return;
    }
    
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    formData.append('playlist_name', playlistName);
    formData.append('add_to_playlist', $('#from-list-add-to-mpd').is(':checked') ? 'true' : 'false');
    formData.append('create_zip', $('#from-list-create-zip').is(':checked') ? 'true' : 'false');
    
    $.ajax({
        type: 'POST',
        url: window.deezer_downloader_api_root + '/playlist/from-file',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            $.jGrowl(`✅ Téléchargement lancé! ${response.songs_count} titre(s). Task ID: ${response.task_id}`, {sticky: false, life: 5000});
            showFromListSuccess(`${response.songs_count} titre(s) en cours de téléchargement. Vérifiez l'onglet Queue pour le statut.`);
            // Vider les champs
            $('#from-list-file').val('');
            $('#from-list-playlist-name').val('');
        },
        error: function(xhr) {
            try {
                const response = JSON.parse(xhr.responseText);
                showFromListError("Erreur: " + response.error);
            } catch(e) {
                showFromListError("Erreur serveur: " + xhr.status);
            }
            $.jGrowl('❌ Erreur lors du téléchargement du fichier', {sticky: false, life: 5000});
        }
    });
});

    // Touche clavier Ctrl+Shift+5 pour aller à l'onglet "From List"
    $(document).on('keydown', function(event) {
        if (event.ctrlKey && event.shiftKey && event.keyCode === 53) { // 5
            $('#nav-from-list').tab('show');
        }
    });

}); // Fermeture du $(document).ready()
