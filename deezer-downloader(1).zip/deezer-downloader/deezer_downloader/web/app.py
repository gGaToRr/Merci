#!/usr/bin/env python3
"""Main Flask application with authentication and modern architecture"""
import os
from subprocess import Popen, PIPE
from functools import wraps
import requests
import atexit
from flask import Flask, render_template, request, jsonify, send_file
from markupsafe import escape
from flask_autoindex import AutoIndex
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity
import warnings
import giphypop

from deezer_downloader.configuration import config
from deezer_downloader.web.music_backend import sched
from deezer_downloader.deezer import deezer_search, init_deezer_session
from deezer_downloader.web.models import db, User, DownloadLog
from deezer_downloader.web.auth import auth_bp
from deezer_downloader.web.admin import admin_bp


def create_app(config_path=None):
    """Application factory"""
    app = Flask(__name__)

    # JWT Configuration
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False

    # Database Configuration
    db_path = os.environ.get('DATABASE_URL', 'sqlite:///deezer_downloader.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions
    db.init_app(app)
    jwt = JWTManager(app)

    # Create tables
    with app.app_context():
        db.create_all()

    # Auto index for downloads
    auto_index = AutoIndex(app, config["download_dirs"]["base"], add_url_rules=False)
    auto_index.add_icon_rule('music.png', ext='m3u8')

    warnings.filterwarnings("ignore", message="You are using the giphy public api key")
    giphy = giphypop.Giphy()

    # Initialize backend
    sched.run_workers(config.getint('threadpool', 'workers'))
    init_deezer_session(config['proxy']['server'], config['deezer']['quality'])

    @atexit.register
    def stop_workers():
        sched.stop_workers()

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)

    # Routes
    @app.route("/")
    def index():
        """Main application page"""
        return render_template("index.html",
                               api_root=config["http"]["api_root"],
                               static_root=config["http"]["static_root"],
                               use_mpd=str(config['mpd'].getboolean('use_mpd')).lower())

    @app.route("/admin")
    def admin_panel():
        """Admin panel page"""
        return render_template("admin.html",
                               api_root=config["http"]["api_root"],
                               static_root=config["http"]["static_root"])

    @app.route("/debug")
    def show_debug():
        """Debug page with logs"""
        if "LOG_FILE" in os.environ:
            cmd = f"tail -n 100 {os.environ['LOG_FILE']}"
        else:
            cmd = f"tail -n 100 {config.get('debug', 'log_file')}"
        proc = Popen(cmd.split(), stdout=PIPE)
        logs = proc.stdout.read().decode('utf-8')
        return render_template("debug.html", logs=logs)

    @app.route("/api/search", methods=["POST"])
    @jwt_required()
    def search():
        """Search for tracks/albums/artists"""
        data = request.get_json()
        user_id = get_jwt_identity()
        
        if 'query' not in data or not data['query']:
            return jsonify({"error": "query required"}), 400

        query = data['query'].strip()
        search_type = data.get('type', 'track').lower()

        if search_type not in ['track', 'album', 'artist']:
            return jsonify({"error": "invalid search type"}), 400

        try:
            results = deezer_search(query, search_type)
            return jsonify({'results': results}), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/download/<music_type>/<music_id>", methods=["POST"])
    @jwt_required()
    def download(music_type, music_id):
        """Download music"""
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404

        data = request.get_json()
        add_to_playlist = data.get('add_to_playlist', False)

        try:
            task_id = sched.enqueue_task({
                'type': music_type,
                'music_id': int(music_id),
                'add_to_playlist': add_to_playlist,
                'playlist_name': None
            })
            return jsonify({'task_id': task_id}), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/playlist/from-list", methods=["POST"])
    @jwt_required()
    def download_from_list():
        """Download from list of titles"""
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404

        data = request.get_json()
        
        if 'titles' not in data or not data['titles']:
            return jsonify({"error": "titles required"}), 400

        if 'playlist_name' not in data or not data['playlist_name']:
            return jsonify({"error": "playlist_name required"}), 400

        titles = data['titles']
        playlist_name = data['playlist_name']
        add_to_playlist = data.get('add_to_playlist', False)
        create_zip = data.get('create_zip', False)

        try:
            task_id = sched.enqueue_task({
                'titles': titles,
                'playlist_name': playlist_name,
                'add_to_playlist': add_to_playlist,
                'create_zip': create_zip
            })
            return jsonify({'task_id': task_id}), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/queue", methods=["GET"])
    @jwt_required()
    def queue():
        """Get queue status"""
        try:
            queue_data = sched.get_queue()
            return jsonify(queue_data), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/version", methods=["GET"])
    def version():
        """Get application version"""
        return jsonify({
            "version": "3.0.0",
            "name": "Deezer Downloader Pro"
        }), 200

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({"error": "Internal server error"}), 500

    return app


# App instance for WSGI servers
app = create_app()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
