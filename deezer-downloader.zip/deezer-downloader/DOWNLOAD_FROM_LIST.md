# Descargar Música desde una Lista

Esta es una nueva funcionalidad que permite descargar múltiples canciones de una lista de títulos.

## Formas de Usar

### Opción 1: Usando un Archivo de Texto (.txt)

Crea un archivo `mis_canciones.txt` con una lista de títulos, uno por línea:

```
The Weeknd - Blinding Lights
Dua Lipa - Levitating
Bad Bunny - Tití
Drake - One Dance
The Weeknd - After Hours
```

Luego envía una petición POST a `/playlist/from-file`:

**Con curl:**
```bash
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@mis_canciones.txt" \
  -F "playlist_name=Mi Playlist" \
  -F "add_to_playlist=true" \
  -F "create_zip=false"
```

**Con Python:**
```python
import requests

with open('mis_canciones.txt', 'r', encoding='utf-8') as f:
    files = {'file': f}
    data = {
        'playlist_name': 'Mi Playlist',
        'add_to_playlist': 'true',
        'create_zip': 'false'
    }
    response = requests.post(
        'http://localhost:5000/playlist/from-file',
        files=files,
        data=data
    )
    print(response.json())
```

### Opción 2: Usando JSON

Envía una petición POST a `/playlist/from-list` con JSON:

**Con curl:**
```bash
curl -X POST http://localhost:5000/playlist/from-list \
  -H "Content-Type: application/json" \
  -d '{
    "titles": [
      "The Weeknd - Blinding Lights",
      "Dua Lipa - Levitating",
      "Bad Bunny - Tití",
      "Drake - One Dance"
    ],
    "playlist_name": "Mi Playlist",
    "add_to_playlist": true,
    "create_zip": false
  }'
```

**Con Python:**
```python
import requests
import json

data = {
    "titles": [
        "The Weeknd - Blinding Lights",
        "Dua Lipa - Levitating",
        "Bad Bunny - Tití"
    ],
    "playlist_name": "Mi Playlist",
    "add_to_playlist": True,
    "create_zip": False
}

response = requests.post(
    'http://localhost:5000/playlist/from-list',
    headers={'Content-Type': 'application/json'},
    data=json.dumps(data)
)
print(response.json())
```

### Opción 3: Desde la Interfaz Web

1. Abre http://localhost:5000
2. Descarga si hay una nueva versión que incluya el interfaz para esta funcionalidad
3. O usa los comandos curl/Python anteriores

## Formatos de Títulos Soportados

Los títulos pueden estar en cualquiera de estos formatos:

- `Artista - Título` (recomendado para mejor búsqueda)
- `Solo el Título`
- `Artista - Título - feat. Otro Artista`

**Ejemplo de archivo válido:**
```
The Weeknd - Blinding Lights
Levitating
Dua Lipa feat. DaBaby - Levitating
Bad Bunny Tití
Drake
```

## Parámetros

### Ambos endpoints usan:

- **titles** (array/lista): Lista de títulos de canciones
  - En `/from-file`: Extraído del archivo automáticamente
  - En `/from-list`: Proporcionado en JSON

- **playlist_name** (string): Nombre de la carpeta donde se guardarán las canciones
  
- **add_to_playlist** (boolean, opcional, default: false):
  - Añade las canciones a la playlist de MPD (si está configurado)

- **create_zip** (boolean, opcional, default: false):
  - Crea un archivo ZIP con todas las canciones

## Respuesta

Ambos endpoints retornan:

```json
{
  "task_id": 12345678,
  "songs_count": 5
}
```

Usa el `task_id` para revisar el progreso en `/queue`

## Monitoreo del Progreso

Para ver el estado de descarga:

```bash
curl http://localhost:5000/queue
```

Respuesta:
```json
[
  {
    "id": 12345678,
    "description": "Downloading songs from file (5 songs)",
    "state": "running",
    "progress": [2, 5],
    "result": null
  }
]
```

## Ubicación de Descargas

Las canciones se guardarán en: `downloads/playlists/{playlist_name}/`

Si `create_zip` es `true`, también encontrarás un archivo ZIP en: `downloads/zips/{playlist_name}.zip`

## Notas

- Si una canción no se encuentra, continuará con la siguiente
- Los títulos duplicados también se descargarán (sin deduplicación)
- El archivo .txt debe estar en formato UTF-8
- Las líneas vacías se ignoran automáticamente
- Es mejor usar el formato "Artista - Título" para búsquedas más precisas

## Ejemplos de Archivos

### archivo_pop.txt
```
The Weeknd - Blinding Lights
Dua Lipa - Levitating
Ariana Grande - thank u, next
Billie Eilish - bad guy
Post Malone - Circles
```

### archivo_pop_es.txt
```
Bad Bunny - Tití
Eslabón Armado - Pa Mí
Feid - Ferlosopher
Karol G - TQG
J Balvin - Tití
```

## Limitaciones Actuales

- Solo soporta búsqueda por nombre (no Spotify links o Deezer links)
- Las canciones se descargan una por una (no en paralelo en cada búsqueda)
- Requiere conexión con Deezer funcionando correctamente
