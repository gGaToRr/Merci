# 🎵 Interface Graphique - Télécharger depuis Liste

## ✨ Nouvelle Interface GUI en Français

La nouvelle fonctionnalité est maintenant intégrée dans l'interface web avec un nouvel onglet **"From List (5)"**.

## 🚀 Comment Utiliser

### Étape 1: Ouvrir l'application

```
http://localhost:5000
```

### Étape 2: Cliquer sur l'onglet "From List"

![tab-from-list]

Vous verrez deux options:

---

## 📝 Option 1: Coller une Liste de Titres

### Comment faire:

1. **Coller les titres** dans la zone de texte
   - Format: Un titre par ligne
   - Peut être "Artiste - Titre" ou juste "Titre"

2. **Exemple:**
   ```
   The Weeknd - Blinding Lights
   Dua Lipa - Levitating
   Bad Bunny - Tití
   Drake - One Dance
   ```

3. **Entrer le nom de la playlist**
   - Dans le champ "Nom de la playlist"
   - Exemple: "Ma Playlist"

4. **Options (optionnelles):**
   - ☑️ Ajouter à la playlist MPD (coché par défaut)
   - ☐ Créer un fichier ZIP

5. **Cliquer sur "Télécharger depuis liste"**

---

## 📂 Option 2: Télécharger un Fichier .txt

### Comment faire:

1. **Préparer un fichier .txt** avec vos titres
   - Un titre par ligne
   - Format UTF-8
   - Exemple: `ma_liste.txt`

2. **Cliquer sur "Sélectionnez un fichier .txt"**
   - Choisir le fichier dans votre ordinateur

3. **Entrer le nom de la playlist**
   - Dans le champ "Nom de la playlist"

4. **Options (optionnelles):**
   - ☑️ Ajouter à la playlist MPD (coché par défaut)
   - ☐ Créer un fichier ZIP

5. **Cliquer sur "Télécharger depuis fichier"**

---

## ✅ Après le Téléchargement

### Message de Succès

```
✅ Succès!
5 titre(s) en cours de téléchargement. Vérifiez l'onglet Queue pour le statut.
```

### Monitorage du Progrès

1. **Aller à l'onglet "Queue (8)"**
2. **Voir le statut:**
   - Description de la tâche
   - État (running, finished, etc.)
   - Progression (X/N)
   - Exceptions le cas échéant

### Accéder aux Fichiers Téléchargés

1. **Cliquer sur l'onglet "Files (6)"**
2. **Naviguer vers**:
   ```
   playlists/
   ├── Ma Playlist/
   │   ├── 01 - Artist - Song.mp3
   │   ├── 02 - Artist - Song.mp3
   │   └── 00 Ma Playlist.m3u8
   └── zips/
       └── Ma Playlist.zip
   ```

---

## ⌨️ Raccourcis Clavier

- **Ctrl+Shift+5** = Aller directement à l'onglet "From List"
- **Ctrl+M** = Focus sur la barre de recherche

---

## 🎨 Interface Visuelle

### Champs du Formulaire

| Champ | Type | Obligatoire | Description |
|-------|------|-------------|-------------|
| Liste de titres | Textarea | ❌ | Texte brut, un titre par ligne |
| Fichier .txt | File | ❌ | Un seul des deux (liste OU fichier) |
| Nom de la playlist | Text | ✅ | Dossier de destination |
| Ajouter à MPD | Checkbox | ❌ | Ajouter à la playlist MPD |
| Créer un ZIP | Checkbox | ❌ | Créer archive ZIP |

### Boutons

| Bouton | Action |
|--------|--------|
| 🟢 Télécharger depuis liste | Lance le téléchargement de la liste |
| 🟢 Télécharger depuis fichier | Lance le téléchargement du fichier |
| 🟡 Effacer | Vide tous les champs |

---

## 📋 Formats Acceptés

### Titres individuels

✅ `The Weeknd - Blinding Lights`
✅ `Blinding Lights`
✅ `The Weeknd ft. Post Malone - Blinding Lights (Remix)`
❌ `https://www.spotify.com/...` (pas accepté)

### Fichiers .txt

```
artiste1.txt
───────────
The Weeknd - Blinding Lights
Dua Lipa - Levitating
Bad Bunny - Tití
(lignes vides ignorées)
Drake - One Dance
```

**Codage requis:** UTF-8

---

## 🔔 Messages d'Erreur

### Erreur: "Veuillez entrer au moins un titre"
- **Cause**: La liste est vide
- **Solution**: Entrez au moins un titre

### Erreur: "Veuillez entrer le nom de la playlist"
- **Cause**: Le champ "Nom de la playlist" est vide
- **Solution**: Donnez un nom à votre playlist

### Erreur: "Veuillez sélectionner un fichier"
- **Cause**: Pas de fichier sélectionné
- **Solution**: Cliquez sur le bouton pour choisir un fichier

### Erreur: "Erreur serveur: 400"
- **Cause**: Problème avec les données envoyées
- **Solution**: Vérifiez le format et réessayez

---

## 💡 Conseils d'Utilisation

1. **Pour une meilleure recherche**: Utilisez le format `Artiste - Titre`
2. **Fichiers volumineux**: Ne posez pas de limite de titres
3. **En cas d'erreur**: Une chanson qui ne se trouve pas n'empêche pas les autres
4. **Vérification**: Allez dans l'onglet "Queue" pour voir le statut

---

## 🎯 Cas d'Utilisation

### 1. Sauvegarder une Playlist Spotify
```
1. Exporter les titres de Spotify en .txt
2. Télécharger le fichier
3. Les chansons se téléchargent automatiquement
```

### 2. Créer une Playlist Personnalisée
```
1. Faire une liste de favorites
2. Coller dans la zone de texte
3. Cliquer "Télécharger"
```

### 3. Télécharger Plusieurs Playlists
```
1. Faire One Request par playlist
2. Chaque playlist dans son dossier
3. Voir la progression dans Queue
```

---

## 🔧 Intégration Technique

### Fichiers Modifiés

- `deezer_downloader/web/templates/index.html` - Ajout de l'interface
- `deezer_downloader/web/static/js/from_list.js` - Logique front-end
- `deezer_downloader/web/app.py` - Endpoints API
- `deezer_downloader/web/music_backend.py` - Logique de téléchargement

### Points d'Entrée API

- **POST** `/playlist/from-list` - JSON
- **POST** `/playlist/from-file` - Multipart form-data

---

## ❓ FAQ

**Q: Combien de titres puis-je télécharger?**
A: Aucune limite théorique, mais ça dépend de votre serveur.

**Q: Qu'arrive-t-il si une chanson ne se trouve pas?**
A: Elle est sautée et le téléchargement continue avec la suivante.

**Q: Puis-je télécharger plusieurs listes en même temps?**
A: Oui, envoyez plusieurs requêtes. Elles s'ajoutent à la queue.

**Q: Où sont téléchargées les chansons?**
A: Dans `downloads/playlists/{nom_de_la_playlist}/`

**Q: Comment créer un fichier .txt?**
A: Bloc-notes » Fichier » Enregistrer sous `nom.txt`

**Q: L'interface est-elle en français ou anglais?**
A: Entièrement en français!

---

## 🎓 Tutoriel Complet

### Scénario: Télécharger "Top 100 2024"

1. **Préparation**
   - Créer un fichier `top100.txt`
   - Entrer 100 titres populaires

2. **Soumission**
   - Ouvrir http://localhost:5000
   - Aller à l'onglet "From List"
   - Choisir le fichier `top100.txt`
   - Nom: "Top 100 2024"
   - Cocher "Créer un ZIP"

3. **Téléchargement**
   - Cliquer "Télécharger depuis fichier"
   - Voir le message de succès
   - Aller à l'onglet "Queue" pour suivre

4. **Récupération**
   - Une fois terminé (Queue = finished)
   - Aller à l'onglet "Files"
   - Télécharger le ZIP `Top 100 2024.zip`

✅ C'est prêt!

---

## 📞 Support

Si vous avez des problèmes:
1. Vérifiez l'onglet "Debug" pour les logs
2. Consultez le fichier `DOWNLOAD_FROM_LIST.md` pour détails techniques
3. Vérifiez que le serveur est en cours d'exécution

---

**Version**: 1.0  
**Date**: Février 2024  
**Langue**: Français 🇫🇷
