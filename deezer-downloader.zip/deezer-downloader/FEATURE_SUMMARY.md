# 🎵 Nueva Funcionalidad: Descargar desde Lista de Títulos

## ✨ Cambios Realizados

Se ha agregado una nueva funcionalidad que permite descargar múltiples canciones a partir de una lista de títulos, ya sea desde un archivo de texto o una lista JSON.

### 📝 Archivos Modificados

1. **`deezer_downloader/web/music_backend.py`**
   - Agregada función `download_songs_from_list()` que:
     - Recibe una lista de títulos de canciones
     - Busca cada título en Deezer
     - Descarga las canciones encontradas
     - Las organiza en una carpeta (playlist)
     - Opcionalmente crea un archivo m3u8 y ZIP
     - Opcionalmente agrega a MPD playlist

2. **`deezer_downloader/web/app.py`**
   - Agregado endpoint `/playlist/from-list` (POST)
     - Acepta JSON con lista de títulos
     - Parámetros: `titles`, `playlist_name`, `add_to_playlist`, `create_zip`
   
   - Agregado endpoint `/playlist/from-file` (POST)
     - Acepta archivo .txt de upload
     - Lee títulos del archivo (uno por línea)
     - Parámetros: `file`, `playlist_name`, `add_to_playlist`, `create_zip`

### 📁 Archivos Creados

1. **`DOWNLOAD_FROM_LIST.md`**
   - Documentación completa de la nueva funcionalidad
   - Ejemplos de uso con curl y Python
   - Explicación de formatos soportados

2. **`download_from_list_example.py`**
   - Script Python listo para usar
   - Demuestra ambos métodos de descarga
   - Incluye monitoreo de progreso

3. **`example_songs_list.txt`**
   - Archivo de ejemplo con 10 canciones
   - Formato recomendado: "Artista - Título"

## 🚀 Cómo Usar

### Opción 1: Desde archivo .txt

```bash
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@canciones.txt" \
  -F "playlist_name=MiPlaylist" \
  -F "add_to_playlist=true" \
  -F "create_zip=false"
```

### Opción 2: Desde JSON

```bash
curl -X POST http://localhost:5000/playlist/from-list \
  -H "Content-Type: application/json" \
  -d '{
    "titles": ["Artist - Song", "Another Artist - Another Song"],
    "playlist_name": "MyPlaylist",
    "add_to_playlist": true,
    "create_zip": false
  }'
```

### Opción 3: Script Python

```bash
python download_from_list_example.py
```

## 📋 Formato de Archivo

El archivo .txt debe contener un título por línea. Formatos soportados:

```
The Weeknd - Blinding Lights
Dua Lipa - Levitating
Another Song Title
Artist - Feat. Another - Song Title
```

## 🎯 Características

- ✅ Descarga de múltiples canciones en una sola petición
- ✅ Búsqueda automática en Deezer
- ✅ Organización en carpetas (playlists)
- ✅ Generación de archivos m3u8
- ✅ Creación opcional de archivos ZIP
- ✅ Manejo de errores (continúa incluso si falla una descarga)
- ✅ Integración con MPD (opcional)
- ✅ Validación de entrada

## 📊 Respuesta de la API

Ambos endpoints retornan:

```json
{
  "task_id": 12345678,
  "songs_count": 5
}
```

Usa el `task_id` para monitorear el progreso en `/queue`

## 📍 Ubicación de Descargas

- Canciones: `downloads/playlists/{playlist_name}/`
- ZIP: `downloads/zips/{playlist_name}.zip`
- M3u8: `downloads/playlists/{playlist_name}/00 {playlist_name}.m3u8`

## 🔧 Validaciones

### Para `/playlist/from-list`:
- `titles`: Array no vacío de strings
- `playlist_name`: String no vacío
- `add_to_playlist`: Boolean (opcional, default: false)
- `create_zip`: Boolean (opcional, default: false)

### Para `/playlist/from-file`:
- Archivo: Debe ser .txt o text/plain
- Codificación: UTF-8
- `playlist_name`: Requerido en form data
- `add_to_playlist`: Boolean string (opcional)
- `create_zip`: Boolean string (opcional)

## 💡 Ejemplos

Ver `DOWNLOAD_FROM_LIST.md` para ejemplos detallados.

## 📝 Notas

- Las canciones se descargan secuencialmente
- Si una canción no se encuentra, continúa con la siguiente
- Los títulos duplicados también se descargarán
- Mejor precisión al usar formato "Artista - Título"
- Las líneas vacías en los archivos se ignoran automáticamente

## 🎓 Casos de Uso

1. **Backup de Spotify**: Exporta tu playlist de Spotify a .txt y descárgala
2. **Playlist personalizada**: Crea listas de canciones favoritas
3. **Descarga masiva**: Descargar muchas canciones de una vez
4. **Automatización**: Script para descargar periódicamente nuevas canciones

## ⚠️ Limitaciones

- Solo búsqueda por nombre (no acepta links de Spotify/Deezer directamente)
- Requiere conexión a Deezer configurada correctamente
- Las búsquedas dependen de la precisión del nombre de la canción

## 🔄 Próximas Mejoras Posibles

- [ ] Soporte para archivos .csv
- [ ] Deduplicación automática
- [ ] Descarga paralela
- [ ] Integración directa con Spotify
- [ ] Interfaz gráfica mejorada
- [ ] Caché de búsquedas
