# 🚀 Quick Start - Descarga desde Lista

## Opción 1️⃣: Archivo de Texto (Más Fácil)

### Paso 1: Crear archivo `canciones.txt`
```
The Weeknd - Blinding Lights
Dua Lipa - Levitating
Bad Bunny - Tití
Drake - One Dance
```

### Paso 2: Ejecutar comando
```bash
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@canciones.txt" \
  -F "playlist_name=Mi Playlist" \
  -F "add_to_playlist=true" \
  -F "create_zip=false"
```

### Respuesta
```json
{
  "task_id": 12345678,
  "songs_count": 4
}
```

✅ ¡Listo! Las canciones se están descargando.

---

## Opción 2️⃣: Un Comando Python

Copia y ejecuta esto en tu terminal:

```python
python3 << 'EOF'
import requests, json

data = {
    "titles": [
        "The Weeknd - Blinding Lights",
        "Dua Lipa - Levitating",
        "Bad Bunny - Tití"
    ],
    "playlist_name": "Mi Playlist",
    "add_to_playlist": True,
    "create_zip": False
}

r = requests.post('http://localhost:5000/playlist/from-list',
                   json=data)
print(r.json())
EOF
```

---

## Opción 3️⃣: Script Python Automático

```bash
python download_from_list_example.py
```

---

## Monitorear Progreso

Ver estado en tiempo real:

```bash
curl http://localhost:5000/queue | python -m json.tool
```

---

## Dónde Están las Descargas

Abre en el navegador:
```
http://localhost:5000/downloads/playlists/
```

---

## ✨ Ejemplos Listos para Usar

```bash
# Descargar con archivo proporcionado
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@example_songs_list.txt" \
  -F "playlist_name=Ejemplo" \
  -F "add_to_playlist=true"

# Descargar con ZIP
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@canciones.txt" \
  -F "playlist_name=Con ZIP" \
  -F "create_zip=true"

# Solo descargar, sin agregar a MPD
curl -X POST http://localhost:5000/playlist/from-file \
  -F "file=@canciones.txt" \
  -F "playlist_name=Solo Descargar" \
  -F "add_to_playlist=false"
```

---

## 🎯 Formatos de Títulos que Funcionan

✅ `The Weeknd - Blinding Lights`  
✅ `Levitating`  
✅ `Dua Lipa - Levitating (Remix)`  
✅ `Bad Bunny feat Drake - Tití`  
✅ `Artist Name`

**Recomendación:** Usa `Artista - Título` para mejor búsqueda

---

## ❓ Preguntas Comunes

**¿Qué pasa si una canción no se encuentra?**
Se salta y continúa con la siguiente.

**¿Puedo editar el archivo mientras se descarga?**
No, hay que esperar. Pero puedes enviar varias descargas en paralelo.

**¿Se descarga en paralelo?**
Las canciones se descargan una por una (secuencial).

**¿Dónde está más documentación?**
Lee `DOWNLOAD_FROM_LIST.md` para detalles completos.

---

## 🔗 API Endpoints

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/playlist/from-file` | Descargar desde archivo .txt |
| POST | `/playlist/from-list` | Descargar desde JSON |
| GET | `/queue` | Ver progreso de descargas |
| GET | `/downloads/` | Ver archivos descargados |

---

## 💡 ¡Eso es todo! 

Ya estás listo para descargar múltiples canciones. 

¿Necesitas ayuda? Revisa `DOWNLOAD_FROM_LIST.md`
