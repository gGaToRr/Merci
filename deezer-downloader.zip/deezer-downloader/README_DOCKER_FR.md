# Lancer deezer-downloader avec Docker (FR)

Ce guide rapide explique comment construire et lancer l'application `deezer-downloader` dans un conteneur Docker local.

Prérequis
- Docker installé (version récente)
- Un token Deezer ARL (cookie) valide : `DEEZER_COOKIE_ARL`
- Un dossier `downloads/` dans le répertoire projet (sera monté dans le conteneur)

1) Builder l'image locale
```bash
cd /home/kaets0ner/Desktop/deezer-downloader
# Build de l'image locale
docker build -t deezer-local:latest .
```

2) Lancer le conteneur (mode simple)
```bash
# Exemple minimal — remplacez <VOTRE_ARL> par votre cookie ARL Deezer
docker run -d \
  --name deezer-local \
  -p 5000:5000 \
  -v "$(pwd)/downloads:/mnt/deezer-downloader" \
  -e DEEZER_COOKIE_ARL="<VOTRE_ARL>" \
  deezer-local:latest
```

Options utiles
- `--restart unless-stopped` : redémarre le conteneur automatiquement
- `-v "$(pwd)/downloads:/mnt/deezer-downloader"` : monte le dossier `downloads/` du host
- Pour des environnements de production, ajoutez des limites de ressources (`--memory`, `--cpus`)

3) Vérifier que le service est démarré
```bash
# Logs du conteneur
docker logs -f deezer-local
# Tester la page d'accueil
curl -I http://localhost:5000
```

4) Utilisation
- Ouvrez l'interface web : http://localhost:5000
- Endpoints API :
  - POST `/playlist/from-list` (JSON)
  - POST `/playlist/from-file` (multipart/form-data)

Exemple rapide (test que l'API répond)
```bash
curl http://localhost:5000/
```

5) Arrêter / supprimer le conteneur
```bash
docker stop deezer-local
docker rm deezer-local
```

6) Dépannage rapide
- Retour `137` ou arrêt brutal : manque de mémoire (OOM). Augmenter la mémoire allouée à Docker ou exécuter hors conteneur.
- `Connection refused` : vérifiez que le conteneur tourne (`docker ps`) et que le port 5000 est mappé.
- Erreurs liées à l'ARL : vérifiez que `DEEZER_COOKIE_ARL` est correct.
- Permissions fichiers : assurez-vous que `downloads/` est accessible par l'utilisateur Docker.

7) docker-compose (optionnel)
Créez un fichier `docker-compose.yml` minimal :
```yaml
version: '3.8'
services:
  deezer:
    image: deezer-local:latest
    build: .
    ports:
      - "5000:5000"
    environment:
      - DEEZER_COOKIE_ARL=<VOTRE_ARL>
    volumes:
      - ./downloads:/mnt/deezer-downloader
    restart: unless-stopped
```

Lancer avec :
```bash
docker-compose up -d --build
```

Remarques
- Le backend (tâches de téléchargement) est géré à l'intérieur du conteneur.
- Si vous préférez exécuter localement sans Docker, utilisez la commande Python du projet (voir `QUICK_START.md`).

Fin du guide Docker.

