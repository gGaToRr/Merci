#!/usr/bin/env python3
"""
Script para descargar canciones usando la nueva funcionalidad de lista.
Ejemplo de uso: python download_from_list_example.py
"""

import requests
import json
import sys
import time
from pathlib import Path

# Configuración
API_BASE_URL = "http://localhost:5000"
DEEZER_DOWNLOADER_BASE_URL = API_BASE_URL

def download_from_list(titles, playlist_name, add_to_playlist=True, create_zip=False):
    """Descarga canciones usando una lista en JSON"""
    print(f"\n📥 Descargando {len(titles)} canciones con el método JSON...")
    
    data = {
        "titles": titles,
        "playlist_name": playlist_name,
        "add_to_playlist": add_to_playlist,
        "create_zip": create_zip
    }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/playlist/from-list",
            headers={"Content-Type": "application/json"},
            data=json.dumps(data),
            timeout=10
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Tarea enqueued correctamente!")
            print(f"   Task ID: {result.get('task_id')}")
            return result.get('task_id')
        else:
            print(f"❌ Error: {response.status_code}")
            print(f"   {response.json()}")
            return None
    except requests.exceptions.ConnectionError:
        print(f"❌ No se puede conectar a {API_BASE_URL}")
        print("   ¿Está corriendo el servidor de deezer-downloader?")
        return None
    except Exception as e:
        print(f"❌ Error: {e}")
        return None


def download_from_file(file_path, playlist_name, add_to_playlist=True, create_zip=False):
    """Descarga canciones usando un archivo .txt"""
    
    file_path = Path(file_path)
    if not file_path.exists():
        print(f"❌ Archivo no encontrado: {file_path}")
        return None
    
    print(f"\n📥 Descargando canciones desde archivo: {file_path}")
    
    try:
        with open(file_path, 'rb') as f:
            files = {'file': f}
            data = {
                'playlist_name': playlist_name,
                'add_to_playlist': 'true' if add_to_playlist else 'false',
                'create_zip': 'true' if create_zip else 'false'
            }
            
            response = requests.post(
                f"{API_BASE_URL}/playlist/from-file",
                files=files,
                data=data,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Tarea enqueued correctamente!")
                print(f"   Task ID: {result.get('task_id')}")
                print(f"   Canciones a descargar: {result.get('songs_count')}")
                return result.get('task_id')
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"   {response.json()}")
                return None
    except requests.exceptions.ConnectionError:
        print(f"❌ No se puede conectar a {API_BASE_URL}")
        print("   ¿Está corriendo el servidor de deezer-downloader?")
        return None
    except Exception as e:
        print(f"❌ Error: {e}")
        return None


def check_queue(task_id=None):
    """Verifica el estado de la queue"""
    try:
        response = requests.get(f"{API_BASE_URL}/queue", timeout=10)
        
        if response.status_code == 200:
            tasks = response.json()
            
            if not tasks:
                print("\n📭 No hay tareas en la queue")
                return
            
            if task_id:
                task = next((t for t in tasks if t['id'] == task_id), None)
                if not task:
                    print(f"\n❌ Tarea {task_id} no encontrada")
                    return
                tasks = [task]
            
            print("\n📊 Estado de la Queue:")
            print("=" * 70)
            for task in tasks:
                print(f"ID: {task['id']}")
                print(f"   Descripción: {task['description']}")
                print(f"   Estado: {task['state']}")
                if task['progress']:
                    progress, total = task['progress']
                    percentage = (progress / total * 100) if total > 0 else 0
                    print(f"   Progreso: {progress}/{total} ({percentage:.1f}%)")
                if task['result']:
                    print(f"   Resultado: {task['result']}")
                if task['exception']:
                    print(f"   ⚠️  Excepción: {task['exception']}")
                print()
        else:
            print(f"❌ Error al conectar: {response.status_code}")
    except Exception as e:
        print(f"❌ Error: {e}")


def main():
    print("🎵 Ejemplo de descarga de canciones desde lista")
    print("=" * 70)
    
    # Opción 1: Descargar desde lista (JSON)
    print("\n\n📝 OPCIÓN 1: Descarga usando JSON")
    print("-" * 70)
    
    canciones = [
        "The Weeknd - Blinding Lights",
        "Dua Lipa - Levitating",
        "Bad Bunny - Tití",
        "Drake - One Dance",
        "The Weeknd - After Hours",
    ]
    
    print(f"Descargando {len(canciones)} canciones...")
    for i, cancion in enumerate(canciones, 1):
        print(f"  {i}. {cancion}")
    
    task_id_1 = download_from_list(
        titles=canciones,
        playlist_name="Mi Playlist JSON",
        add_to_playlist=True,
        create_zip=False
    )
    
    # Opción 2: Descargar desde archivo
    print("\n\n📝 OPCIÓN 2: Descarga usando archivo .txt")
    print("-" * 70)
    
    example_file = Path(__file__).parent / "example_songs_list.txt"
    if example_file.exists():
        task_id_2 = download_from_file(
            file_path=example_file,
            playlist_name="Mi Playlist Archivo",
            add_to_playlist=True,
            create_zip=False
        )
    else:
        print(f"⚠️  Archivo de ejemplo no encontrado: {example_file}")
        task_id_2 = None
    
    # Monitorear progreso
    print("\n\n📊 Monitoreando progreso...")
    print("-" * 70)
    
    if task_id_1:
        check_queue(task_id_1)
    
    if task_id_2:
        time.sleep(2)
        check_queue(task_id_2)
    
    # Mostrar instrucciones
    print("\n\n💡 Para monitorear el progreso manualmente:")
    print(f"   curl {API_BASE_URL}/queue")
    
    print("\n\n💡 Para ver todas las descargas en el navegador:")
    print(f"   Abre: {API_BASE_URL}/downloads/")


if __name__ == "__main__":
    main()
