/**
 * Animations et effets visuels
 */

// Animations au chargement
document.addEventListener('DOMContentLoaded', function() {
    initAnimations();
});

function initAnimations() {
    // Ripple effect on buttons
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            createRipple(e);
        });
    });

    // Smooth scroll animation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Stagger animation for list items
    observeElements('.search-result-item', (element, index) => {
        element.style.animation = `slideUp 0.4s ease-in-out ${index * 0.05}s forwards`;
        element.style.opacity = '0';
    });

    // Count animation for stats
    observeElements('[data-count]', animateCounter);
}

// Ripple effect
function createRipple(event) {
    const button = event.currentTarget;
    const circle = document.createElement('span');
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;

    circle.style.width = circle.style.height = diameter + 'px';
    circle.style.left = event.clientX - button.offsetLeft - radius + 'px';
    circle.style.top = event.clientY - button.offsetTop - radius + 'px';
    circle.classList.add('ripple');

    const ripple = button.querySelector('.ripple');
    if (ripple) ripple.remove();

    button.appendChild(circle);
}

// Observer pattern pour les animations
function observeElements(selector, callback) {
    if (!window.IntersectionObserver) {
        document.querySelectorAll(selector).forEach(callback);
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                callback(entry.target, index);
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    document.querySelectorAll(selector).forEach(el => observer.observe(el));
}

// Counter animation
function animateCounter(element) {
    const target = parseInt(element.dataset.count);
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current).toLocaleString();
    }, 16);
}

// Scroll animations
window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    
    // Parallax effect
    document.querySelectorAll('[data-parallax]').forEach(element => {
        const speed = element.dataset.parallax || 0.5;
        element.style.transform = `translateY(${scrolled * speed}px)`;
    });

    // Fade in on scroll
    document.querySelectorAll('[data-fade-in]').forEach(element => {
        const rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
            element.classList.add('visible');
        }
    });
});

// Loading animation
function showLoadingAnimation(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const loader = document.createElement('div');
    loader.className = 'loader-spinner';
    loader.innerHTML = `
        <div class="spinner"></div>
        <p style="color: white; margin-top: 16px;">Chargement...</p>
    `;
    
    container.appendChild(loader);
    return loader;
}

function hideLoadingAnimation(loader) {
    if (loader) {
        loader.style.animation = 'fadeOut 0.3s ease-in-out';
        setTimeout(() => loader.remove(), 300);
    }
}

// Modal animations
function animateModalOpen(modal) {
    modal.classList.remove('hidden');
    modal.style.animation = 'fadeIn 0.3s ease-in-out';
}

function animateModalClose(modal) {
    modal.style.animation = 'fadeOut 0.3s ease-in-out';
    setTimeout(() => modal.classList.add('hidden'), 300);
}

// Form animations
function animateFormError(formElement) {
    formElement.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
        formElement.style.animation = '';
    }, 500);
}

function animateFormSuccess(formElement) {
    formElement.style.animation = 'pulse 0.6s ease-in-out';
    setTimeout(() => {
        formElement.style.animation = '';
    }, 600);
}

// Pulse animation
function createPulseAnimation(element) {
    element.style.animation = 'pulse 1s infinite';
}

// CSS for ripple and animations
const style = document.createElement('style');
style.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.5);
        transform: scale(0);
        animation: ripple-animation 0.6s ease-out;
        pointer-events: none;
    }

    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }

    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
    }

    @keyframes fadeOut {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }

    .loader-spinner {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 40px;
    }

    .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid rgba(255, 255, 255, 0.1);
        border-top-color: #6366f1;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }

    .visible {
        animation: slideUp 0.6s ease-out forwards;
    }

    [data-fade-in] {
        opacity: 0;
    }

    .fade-in-animation {
        animation: fadeIn 0.6s ease-in-out forwards;
    }
`;
document.head.appendChild(style);

// Export functions
window.showLoadingAnimation = showLoadingAnimation;
window.hideLoadingAnimation = hideLoadingAnimation;
window.animateModalOpen = animateModalOpen;
window.animateModalClose = animateModalClose;
window.animateFormError = animateFormError;
window.animateFormSuccess = animateFormSuccess;
window.createPulseAnimation = createPulseAnimation;
